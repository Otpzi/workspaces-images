# About This Image

This Image contains a browser-accessible Oracle Linux 7 Desktop with various productivity and development apps installed.

![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://5856039.fs1.hubspotusercontent-na1.net/hubfs/5856039/dockerhub/oracle-7-desktop.png "Image Screenshot"
