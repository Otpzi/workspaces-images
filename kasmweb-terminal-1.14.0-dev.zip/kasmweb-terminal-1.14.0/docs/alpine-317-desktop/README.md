# About This Image

This Image contains a browser-accessible Alpine 3.17 Desktop with various productivity and development apps installed.

![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://info.kasmweb.com/hubfs/dockerhub/image-screenshots/alpine-317-desktop.png "Image Screenshot"
