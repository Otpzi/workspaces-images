#!/usr/bin/env bash
set -ex

apk add --no-cache \
  nano \
  vim \
  xdotool \
  zip
