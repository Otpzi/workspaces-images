# About This Image

This Image contains an unofficial browser-accessible version of the [Trace Labs OSINT Image](https://www.tracelabs.org/initiatives/osint-vm).

![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://f.hubspotusercontent30.net/hubfs/5856039/dockerhub/image-screenshots/tracelabs.jpg "Image Screenshot"
