# About This Image

This Image contains a browser-accessible version of [Retroarch](https://www.retroarch.com/).

![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://5856039.fs1.hubspotusercontent-na1.net/hubfs/5856039/dockerhub/image-screenshots/retroarch.png "Image Screenshot"

# Environment Variables

* `APP_ARGS` - Additional arguments to pass to the application when launched.
