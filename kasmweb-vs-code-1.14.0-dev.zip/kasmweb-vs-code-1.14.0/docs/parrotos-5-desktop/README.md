# About This Image

This Image contains a browser-accessible Parrot OS 5 Desktop with various productivity and development apps installed.

![Screenshot][Image_Screenshot]

[Image_Screenshot]: https://info.kasmweb.com/hubfs/dockerhub/image-screenshots/parrotos-5-desktop.png "Image Screenshot"
