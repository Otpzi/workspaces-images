# Installation

1. Build de l'appli : 
docker build -t kasmweb/vs-code:1.14.0 .

2. Installer l'appli
sudo docker run --rm -it --shm-size=512m -p 6901:6901 -e VNC_PW=password kasmweb/vs-code:1.14.0


# Fonctionnalités
- Mode root
- Navigateur intégré pour la connexion
- Outils et git installés.
